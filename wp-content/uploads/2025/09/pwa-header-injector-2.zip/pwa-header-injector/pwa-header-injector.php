<?php
/**
 * Plugin Name: PWA Support
 * Description: Automatikusan hozzáadja a manifest.json-t és a service worker regisztrációt, valamint install gombot jelenít meg a főoldalon.
 * Version: 1.1
 * Author: PZs
 */

if (!defined('ABSPATH')) exit; // biztonság

// Manifest és Service Worker kód a <head>-be
function pwa_support_add_tags() {
    if (!is_front_page()) return; // csak a kezdőlapra tegye be
    ?>
    <link rel="manifest" href="/manifest.json">
    <script>
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('./sw.js', {scope: './'})
          .then(reg => console.log("Service Worker registered", reg))
          .catch(err => console.error("Service Worker registration failed", err));
      }
    </script>
    <?php
}
add_action('wp_head', 'pwa_support_add_tags');

// Install gomb a főoldal tartalma elé
function pwa_support_install_button($content) {
    if (is_front_page()) {
        $button = '
        <div style="text-align:center; margin:20px 0;">
            <button id="installPWA" style="
                display:none;
                padding:10px 20px;
                font-size:16px;
                border:none;
                border-radius:8px;
                background:#0073aa;
                color:white;
                cursor:pointer;
            ">
              📲 Telepítés
            </button>
        </div>
        <script>
          let deferredPrompt;
          const installBtn = document.getElementById("installPWA");

          window.addEventListener("beforeinstallprompt", (e) => {
            e.preventDefault();
            deferredPrompt = e;
            installBtn.style.display = "inline-block";
          });

          installBtn.addEventListener("click", () => {
            if (deferredPrompt) {
              deferredPrompt.prompt();
              deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === "accepted") {
                  console.log("PWA telepítve!");
                } else {
                  console.log("Telepítés elutasítva");
                }
                deferredPrompt = null;
                installBtn.style.display = "none";
              });
            }
          });
        </script>
        ';
        return $button . $content;
    }
    return $content;
}
add_filter('the_content', 'pwa_support_install_button');
